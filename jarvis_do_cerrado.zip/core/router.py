from core.rules import match_rule
from core.brain_ai import BrainAI

brain_ai = BrainAI()

async def route(text: str):
    rule = match_rule(text)
    if rule:
        return {
            "intent": rule["intent"],
            "action": rule["action"],
            "entity": rule["entity"],
            "confidence": 1.0,
            "source": "rule"
        }

    # S� aqui entra IA
    return await brain_ai.process(text)
