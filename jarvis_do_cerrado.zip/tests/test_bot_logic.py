import unittest
from unittest.mock import MagicMock, patch, AsyncMock
import sys
import os
import json
import asyncio
from datetime import datetime

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.brain import Brain
from core.executor import Executor
from config import Config
from database.persistence import Persistence
from core.events import Event

class TestHomeAssistantBot(unittest.IsolatedAsyncioTestCase):

    @classmethod
    def setUpClass(cls):
        # Use in-memory DB for tests
        Persistence.init_db()

    @patch('core.brain.genai')
    async def test_brain_process_intent(self, mock_genai):
        mock_model = MagicMock()
        mock_genai.GenerativeModel.return_value = mock_model

        mock_response = MagicMock()
        mock_response.text = '[{"intent": "smarthome", "action": "turn_on", "device": "luz_sala"}]'
        # Since Brain.process_intent is async, generate_content is still sync in the lib,
        # but our wrapper makes the method async. It's fine.
        mock_model.generate_content.return_value = mock_response

        brain = Brain()
        result = await brain.process_intent("Liga a luz da sala")
        self.assertIsInstance(result, list)

    @patch('modules.network.send_magic_packet')
    @patch('core.utils.asyncio.sleep')
    async def test_executor_wol_retry(self, mock_sleep, mock_send_magic):
        # Configured retries=2.
        # Call 1: Exception. Retry logic catches, sleeps, loops.
        # Call 2: Success (returns None).
        mock_send_magic.side_effect = [Exception("Fail 1"), None]

        Config.PC_MAC = "AA:BB:CC:DD:EE:FF"
        app = MagicMock()
        executor = Executor(app)

        intent_data = [{"intent": "network", "action": "wake_pc"}]

        response = await executor.execute(intent_data, chat_id=123)

        self.assertIn("Pacote WoL enviado", response)
        self.assertEqual(mock_send_magic.call_count, 2)

    async def test_persistence_event_log(self):
        event = Event(type="test.event", source="test", payload={"foo": "bar"})
        Persistence.log_event(event)

        # Verify DB
        import sqlite3
        conn = sqlite3.connect(os.path.join(os.path.dirname(__file__), "../database/homebot.db"))
        c = conn.cursor()
        c.execute("SELECT type FROM events WHERE id=?", (event.id,))
        row = c.fetchone()
        conn.close()

        self.assertEqual(row[0], "test.event")

    @patch('core.executor.set_reminder_job')
    async def test_executor_reminder_persistence(self, mock_set_reminder):
        app = MagicMock()
        executor = Executor(app)

        intent_data = [{
            "intent": "reminder",
            "action": "set",
            "text": "Teste DB",
            "minutes": 5,
            "repeat": True
        }]

        await executor.execute(intent_data, chat_id=123)

        # Verify DB
        rows = Persistence.get_pending_tasks()
        found = False
        for row in rows:
            if row[2] == "Teste DB": # text column
                found = True
                break
        self.assertTrue(found)

if __name__ == '__main__':
    unittest.main()
